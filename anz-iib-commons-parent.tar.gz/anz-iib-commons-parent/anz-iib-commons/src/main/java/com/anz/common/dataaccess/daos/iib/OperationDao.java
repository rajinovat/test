package com.anz.common.dataaccess.daos.iib;

import com.anz.common.dataaccess.AbstractDao;
import com.anz.common.dataaccess.daos.IOperationDao;
import com.anz.common.dataaccess.daos.iib.repos.OperationRepository;
import com.anz.common.dataaccess.models.iib.Operation;

public class OperationDao extends AbstractDao<Operation, String, OperationRepository> implements IOperationDao {


	
}
