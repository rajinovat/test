package com.anz.common.dataaccess.daos.iib;

import com.anz.common.dataaccess.AbstractDao;
import com.anz.common.dataaccess.daos.ILookupDao;
import com.anz.common.dataaccess.daos.iib.repos.LookupRepository;
import com.anz.common.dataaccess.models.iib.Lookup;

public class LookupDao extends AbstractDao<Lookup, String, LookupRepository> implements ILookupDao {


	
}
