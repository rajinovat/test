/**
 * 
 */
package com.anz.common.transform;

import java.io.Serializable;

/**
 * @author sanketsw
 *
 */
public interface ITransformPojo extends Serializable {

}
