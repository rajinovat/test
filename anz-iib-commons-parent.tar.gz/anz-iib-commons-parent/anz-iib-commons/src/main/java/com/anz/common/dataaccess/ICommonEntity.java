package com.anz.common.dataaccess;

public interface ICommonEntity {
	
	public String getKey();

}
