package com.anz.common.error;

/**
 * @author root
 *
 */
public class ServiceInfo {
	
	String serviceName;
	
	String messageFlowName;
	
	String version;

	/**
	 * @return the serviceName
	 */
	public String getServiceName() {
		return serviceName;
	}

	/**
	 * @param serviceName the serviceName to set
	 */
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	/**
	 * @return the messageFlowName
	 */
	public String getMessageFlowName() {
		return messageFlowName;
	}

	/**
	 * @param messageFlowName the messageFlowName to set
	 */
	public void setMessageFlowName(String messageFlowName) {
		this.messageFlowName = messageFlowName;
	}

	/**
	 * @return the version
	 */
	public String getVersion() {
		return version;
	}

	/**
	 * @param version the version to set
	 */
	public void setVersion(String version) {
		this.version = version;
	}
	
	
}
