/**
 * 
 */
package com.anz.common.compute;

/**
 * Enum to define the target output terminal
 * @author sanketsw
 *
 */
public enum OutputTarget {
	DEFAULT, 
	ALTERNATE

}
