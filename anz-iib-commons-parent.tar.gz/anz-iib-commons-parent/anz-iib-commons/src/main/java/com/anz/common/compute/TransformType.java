/**
 * 
 */
package com.anz.common.compute;

/**
 * @author sanketsw
 * 
 */
public enum TransformType {

	HTTP_HHTP, 
	MQ_MQ,
	HTTP_MQ,
	MQ_HTTP,
	UNSPECIFIED

}
