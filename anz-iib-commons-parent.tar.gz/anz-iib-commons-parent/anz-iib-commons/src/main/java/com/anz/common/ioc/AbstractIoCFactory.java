package com.anz.common.ioc;

public abstract class AbstractIoCFactory implements IIoCFactory {

	public abstract IIoCFactory getInstance();

}
